loadExpMeas<- function(expDat, countTable, totalReads = NULL){
  
  designFactors <- c("Sample","Rep")
  
  # Check for countable input errors
  for (i in 2:length(colnames(countTable))){
      if (str_count(colnames(countTable[c(i)]),"_") != 1){
        stop("Check countTable column names for use of underscore (_)")
      }
  }
  if (anyDuplicated(colnames(countTable)) > 0){
    stop("Column names must be unique sample IDs")  
  }
  sampleInfo = expDat$sampleInfo
  # Pull idCols out of expDat
  idCols <- expDat$erccInfo$idCols 

  if (sampleInfo$totalSeqReads == F){
    expDat$totalReads = NULL
  }else{
    expDat$totalReads = totalReads
  }
  
  Transcripts = countTable
  
  # Import data based on analysis type from SEQC main project
    
   # force names to be ERCC- and first column name to Feature
   names(Transcripts)[1] = "Feature"
   Transcripts$Feature = gsub("ERCC_","ERCC-",Transcripts$Feature)
   #Transcripts$Feature = gsub(".","-",Transcripts$Feature)
   Transcripts$Feature = gsub(":","",Transcripts$Feature)
   
   # get data frames with just the ERCCs and just the human genes
   TranscriptsERCCOnly = Transcripts[c(grep("ERCC-0", Transcripts$Feature)),]
   TranscriptsHumanOnly = Transcripts[-c(grep("ERCC-0", Transcripts$Feature)),]
   
   # Remove ERCCs in the definition file that are not in the count data file
   idCols = idCols[match(TranscriptsERCCOnly$Feature,idCols$Feature),]
   
   # Remove ERCCs without a Ratio
   idCols = idCols[which(is.finite(idCols$Ratio)),]
   
   # Remove ERCCs from count data and idCols that are absent from the experiment
   TranscriptsERCCOnly = TranscriptsERCCOnly[match(idCols$Feature,
                                                  TranscriptsERCCOnly$Feature),]
   Transcripts = rbind(TranscriptsERCCOnly, TranscriptsHumanOnly)
   
   #############################################################################
   sample1 <- sampleInfo$sample1Name 
   sample2 <- sampleInfo$sample2Name

  designMat <- getDesignMat(expressionData = Transcripts,
                               factorList = designFactors,
                               patternSplit = '_')
  # write Transcript csv file to directory
  #write.csv(Transcripts, paste(sampleInfo$filenameRoot,"Transcripts.csv",sep="."),
  #          row.names = F)
  # collect everything to add to expDat
  expDat = append(expDat, list(Transcripts = Transcripts,
                               designMat = designMat,
                               sampleNames = c(sample1,sample2),
                               idCols = idCols))
  return(expDat)

}