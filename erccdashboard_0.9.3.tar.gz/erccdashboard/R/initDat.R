#' Initialize the expDat list
#'
#' @param expTable    data frame, the first column contains names of 
#'                      genes or transcripts (Feature) and the remaining columns
#'                      are counts for sample replicates spiked with ERCC 
#'                      controls
#' @param totalReads    vector of totalReads to use for library size
#'                      normalization
#' @param filenameRoot  string root name for output files
#' @param sample1Name   string name for sample 1 in the gene expression 
#'                      experiment
#' @param sample2Name   string name for sample 2 in the gene expression
#'                      experiment
#' @param ERCCMixes     Name of ERCC mixture design, "RatioPair" is 
#'                      default, the other option is "Single"
#' @param ERCCdilution  unitless dilution factor used in dilution of the Ambion 
#'                      ERCC spike-in mixture solutions 
#' @param spikeVol      volume in microliters of diluted ERCC mix spiked into
#'                      the total RNA samples
#' @param totalRNAmass  mass in micrograms of total RNA spiked with diluted ERCC
#'                      mixtures 
#' @param choseFDR      False Discovery Rate for differential expression testing
#'                      , default is 0.05
#' @param userMixFile   optional filename input, default is NULL, if ERCC 
#'                      control ratio mixtures other than the Ambion product
#'                      were used then a userMixFile can be used for the analysis
#'                                         
#' 
#' @export
#' @examples
#' load(file = system.file("data/SEQC.RatTox.Example.RData",
#'      package = "erccdashboard"))
#'      
#' expDat = initDat(expTable = COH.RatTox.ILM.MET.CTL.countTable, totalReads = 
#'                  COH.RatTox.ILM.MET.CTL.totalReads, filenameRoot = "COH.ILM",
#'                  sample1Name = "MET", sample2Name = "CTL", 
#'                  ERCCMixes = "Ambion4PlexPair", ERCCdilution = 1/100, 
#'                  spikeVol = 1, totalRNAmass = 0.500)
#'                  
#' summary(expDat)

initDat <- function(expTable, totalReads, filenameRoot, sample1Name, 
                    sample2Name, ERCCmixes, ERCCdilution, spikeVol, 
                    totalRNAmass, choseFDR, userMixFile){
  ## These variables may become options for user later, for now they will be defined as
  ## internal default values
  totalSeqReads = T
  libeSizeNorm = T
  
  myXLimMA = c(-10,15)
  myYLimMA = c(-4,4)
  myXLim = c(-10,15)
  myYLim = NULL
  if (missing(choseFDR)){
    choseFDR = 0.05
    cat(paste("Default choseFDR = ", choseFDR))
  }
  ## Do some library loading
  library("QuasiSeq")
  library("ROCR")
  library("edgeR")
  library("grid")
  library("gridExtra")
  library("reshape2")
  
  ##############################
  
  sampleInfo = list(sample1Name = sample1Name,
                    sample2Name = sample2Name, choseFDR = choseFDR,
                    ERCCdilution = ERCCdilution, ERCCmixes = ERCCmixes,
                    spikeVol = spikeVol, totalRNAmass = totalRNAmass, 
                    totalSeqReads = totalSeqReads, 
                    libeSizeNorm = libeSizeNorm)
  
  plotInfo = list(myXLimMA = myXLimMA, myYLimMA = myYLimMA,
                    myXLim = myXLim, myYLim = myYLim)
  
  expDat = list(sampleInfo = sampleInfo, plotInfo = plotInfo)
  
  if (exists("filenameRoot")){
    expDat <- dashboardFile(expDat,filenameRoot = filenameRoot)  
  }else{
    stop("The filenameRoot character string has not been defined!")
  }
  
  
  ###############################################################################
  # Run loadERCCInfo function to obtain ERCC information
  expDat <- loadERCCInfo(expDat, erccMixType=ERCCmixes,userMixFile=userMixFile)
  
  ###############################################################################
  # Assume user has created data frame countTable and totalReads vector
  # process those data files to add to expDat structure
  expDat <- loadExpMeas(expDat, expTable, totalReads)
  
  ###############################################################################
  # library size normalize the data
  expDat <- libeSizeNorm(expDat)
  
  ###############################################################################
  # length normalize the ERCC concentrations
  expDat <- prepERCCDat(expDat)
  
  # Estimate the mean library size factor for the data to use to estimate
  # corresponding concentrations for LODR
  expDat <- estMnLibeFactor(expDat, cnt = expDat$Transcripts)
  
  expDat <- plotAdjust(expDat)
  
  return(expDat)
  
}