### Analyze Taqman data

#### MAQC 1 Taqman qRTPCR data

# Get the probe mapping information
# This maps gene ids and accession numbers to the 997 Taqman probes
probeMap <- read.delim(url(paste0("http://www.ncbi.nlm.nih.gov/pmc/articles/",
                                  "PMC3272078/bin/NIHMS352334-supplement-Suppl",
                                  "__Table_2.txt")))

# Get the Taqman data from GEO 
url("ftp://ftp.ncbi.nlm.nih.gov/geo/platforms/GPL4nnn/GPL4097/soft/")

