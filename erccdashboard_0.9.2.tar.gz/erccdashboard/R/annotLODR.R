#' Annotate signal-abundance and ratio-abundance plots with LODR
#'
#' @param expDat    list, contains input data and stores analysis results
#' 
#' @export
#' @examples
#' 
#' expDat <- annotLODR(expDat)
#' # The LODR estimates are used to annotate the signal-abundance plot
#' expDat$Figures$plotdynRangeAnnot
#' 
#' # and the ratio-abundance plot
#' expDat$Figures$plotRatioAnnot
#' 
annotLODR <- function(expDat){
  
  LODR.annot.ERCC <- printLODRres(expDat)
  
  expDat <- dynRangePlotLODR(dynRangeRes = expDat$Figures$plotdynRange,
                   LODR.annot.ERCC = LODR.annot.ERCC)
  
  expDat<- maConcPlot(expDat, LODR.annot.ERCC, alphaPoint = 0.8, r_mAdjust = T, 
                        replicate = T)
  
  return(expDat)
}